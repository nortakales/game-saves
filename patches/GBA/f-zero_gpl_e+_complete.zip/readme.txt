﻿Overview
===============================================================================

The Japanese version of F-Zero: GP Legend has support for additional content
scanned from e-Reader cards. Content includes new courses, challenge ghosts and
unlockable racers. The cards were distributed in two series: 40 cards in the
Pillow Pack set available at retailers, and 20 cards in another set available
only through participating Carddass vending machines. The Carddass cards have
long evaded detection, holding captive some exclusive content not available in
the Pillow Pack set. They were recently found and archived, however, and
preserved for the future of gaming.

This hack is a mod for all three versions of F-Zero: GP Legend (Japanese, North
American, PAL) that incorporates all of the e-Reader content directly into the
game. The modifications are as follows:

All versions
 • Time Attack and Training are now permanently unlocked
 • Card e+ is now permanently added to Time Attack and Training
 • All 20 e-Reader courses are available in the Card e+ cup
 • Challenge ghosts are available on select courses
 • Existing save files will automatically be migrated on first boot

Japanese version
 • e-Reader exclusive machines are now available if they were still locked
 • The e-Reader+ option has been removed from the Link menu

PAL version
 • The Card e+ cup menu has been localized for each language



Courses
===============================================================================

Within the Time Attack and Training cup select menus is an option for a
"Card e+" cup containing the e-Reader courses. In the original Japanese
version, up to 5 such courses could be saved to the cartridge at a time. With
the mod, all 20 of the courses that were released on e-Reader cards are
available.

The following e-Reader courses are available:

 • #001  Mute City   Tiles Square     タイルズ・スクエア
 • #002  Red Canyon  Long Drive       ドラコン
 • #003  Sand Ocean  Undulation Wave  アンジュレーションウェーブ
 • #004  White Land  Vingt-Cinq Rink  ヴァンサンク＝リンク
 • #005  Fire Field  Rumble Grand     ランブルグランド
 • #006  Illusion    Death Hand       デスハンド
 • #007  Red Canyon  Best Choice      ベストチョイス
 • #008  Mist Flow   Flower 3         フラワー３
 • #009  Red Canyon  Dirt Dart        ダートダート
 • #010  Port Town   Dukedom Circuit  デュークダムサーキット
 • #011  Mute City   Counter          カウンター
 • #012  Lightning   Grid Maze        グリッドメイズ
 • #013  Big Blue    Pigeon           ピジョン
 • #014  Sand Ocean  Make or Break    メイクオアブレイク
 • #015  Lightning   Light Bulb       ライトバルブ
 • #016  Port Town   Falcon           ファルコン
 • #017  Illusion    Ace of Hearts    エースオブハート
 • #018  Silence     Kamitoba         カミトバ
 • #019  Mist Flow   Screw            スクリュー
 • #020  White Land  Yeti Foot        イエティフット



Ghosts
===============================================================================

Challenge ghosts were distributed on e-Reader cards, which fill the role of the
"Staff Ghost" feature in other F-Zero games. In the original Japanese version,
the challenge ghost replaced the current ghost saved on the cartridge (if any).
With the mod, the challenge ghosts can be accessed independently from the saved
ghost.

The course selection menu was altered to accommodate the selection of the
challenge ghosts. A new "e+" setting is available via the R button for courses
with challenge ghosts. The saved ghost may exist on a course that also has a
challenge ghost.

The following courses have challenge ghosts available:

 • Mute City   Tradition Park
 • Red Canyon  Junction
 • Lightning   Volute
 • Fire Field  Blast Track
 • Mute City   Expansion Park



Other
===============================================================================

In the Japanese version, four machines could only be unlocked by using e-Reader
cards. With the mod, these machines are automatically unlocked if they were
locked in the save file.

The following machines are made available in the Japanese version:

 • Night Thunder
 • Sonic Phantom
 • Elegance Liberty
 • Moon Shadow

To prevent erroneous operation, the e-Reader+ menu option in the Link menu was
removed from the Japanese version.

In the PAL version, the Card e+ course selection menu was never localized for
languages other than English. Translation and graphical work was done for the
mod in order to provide localizations.



Credits
===============================================================================
e-Reader Data   FighBat, Richard Taro, those helpful card archives online
Translations    augitesoul, azoth, DeProgrammer, jorgeche, KR155E, WaluigiBSOD
Testing         Jayricochet, Matthew Green, Nathan M., the_androgyne, Valyssa
R&D/Author      Guy Perfect
September 4, 2020

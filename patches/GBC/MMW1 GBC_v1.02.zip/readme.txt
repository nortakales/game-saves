Mega Man World: Dr. Wily's Revenge
GBC Conversion Hack V1.02

This converts Dr. Wily's Revenge into a GBC game. Additional
detail is added to background graphics, and weapon icons and
colors for Mega Man have been added to the game. Slowdown should
also be improved due to GBC double-speed.

Known Errors:
-When selecting a Robot Master, there are less stars on the top half of
 the screen due to how the faces work.
-When dying to the final boss, the mouth sprite fades in before the background
 on reload.
-Occasional flicker of enemy sprites (this is a problem with
 the original game)
 
Version Log:
1.02 - Changes Elec Man stage palette
	 Fixes a bug where Mega Man's face is sometimes drawn twice
	 Slightly changes ending graphics
1.01 - Fixes an error with VisualBoyAdvance loading Wily 1
	 Fixes a frame of Ice Man's animations that had an incorrect face assignment
1.0  - Initial release

Credits:
	Hacking/Colors: 
	-SpecialAgentApe
	Weapon Icons:
	-Superjustinbros
	Title Logo:
	-SuxMenner, with modifications 
	Enker GFX and palettes:
	-Kensuyjin33 
	Cutting Wheel GFX/Misc:
	-Tails Gaming Power
	Special Thanks:
	-marc_max
A big overhaul of Revenge Of The Gator for the gameboy.

Adding colors, fixes and improvements.

This hack includes:

* Colors everywhere
* New version runs in double speed mode, so no slowdowns
* High score table now saves
* Various bug fixes, especially on the title screen
* Change the 3 Egg plant penalty to remove 1 from each bonus multiplier, to a minimum of 1x1000

Apply to "Pinball - Revenge of the Gator (U) [!].gb" md5sum = 113d8f894df6b8c3641b2ba1fe60c250

History
2023/01/23 v1.0


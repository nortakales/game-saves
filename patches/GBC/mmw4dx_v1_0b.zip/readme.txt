================================================

           MEGA MAN WORLD 4 DX v1.0
           by kensuyjin33 & marc_max

================================================


The fourth entry in the Mega Man series in Game Boy got remastered!
Mega Man IV is a highly praised game, not only for its excellent level design
but also for introducing mechanics that would become standard in the series.

From now on, you are able to play its best version: in full color!

FEATURES
- full color conversion
- slowdowns removed
- NES styled pause screen
- option to toggle charged megabuster recoil
- works in real hardware and emulators



PATCHING INFORMATION
--------------------
You must provide the original Mega Man IV USA ROM:

Mega Man IV (USA).gb
CRC32: abcea00d
MD5:   8a00f627b8902c92327435901c249e19
SHA-1: 6f0901db2b5dcaace0215c0abdc21a914fa21b65
 
Apply the patch here: https://www.romhacking.net/patch/
(some emulators may require a .gbc extension, so make sure you rename it after
patching)



MORE COLORIZED MEGA MAN!
------------------------
Check out other remastered Game Boy Mega Man games made by fans!
- Mega Man World: Dr. Wily's Revenge GBC (by SpecialAgentApe)
  https://www.romhacking.net/hacks/7492/
- Mega Man World 2 GBC (by SpecialAgentApe and forple)
  https://www.romhacking.net/hacks/8688/
- Mega Man World 3 DX
  https://www.marcrobledo.com/game-boy/mega-man-world-3-dx/
- Mega Man World 5 DX
  https://www.marcrobledo.com/game-boy/mega-man-world-5-dx/



CHANGELOG
---------
v1.0b (2024-12-22)
- fixed: Bright Stopper made Wily Capsule visible after closing pause menu
- fixed: Satellite Cannon and Hunter bosses blinking iframes
- fixed: wrong palette in a Ring Man intro frame
- fixed: wrong palette in Wily spaceship during escape cutscene in some circumstances
- fixed: dialog box palette in Weapon Get demo with some weapons
- fixed: wrong OBJ palettes after Ballade explosion in specific circumstances
- fixed: original game debug menu

v1.0 (2024-12-17)
- first version



CREDITS
-------
kensuyjin33 - graphics
marc_max - reverse engineering & hacking

thanks to Genares, StahlbolzenSC2, amaturehd & NooblarGaming for their deep betatesting!
thanks to the GB Colorization team for their help and advice!


DISCLAIMER
----------
This is a fan created hack, no copyright or trademark infringement is intended.
Mega Man is a trademark © of Capcom. We are not affiliated nor endorsed by Capcom.

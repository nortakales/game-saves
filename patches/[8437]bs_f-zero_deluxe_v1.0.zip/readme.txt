﻿BS F-Zero Deluxe - v1.0

Overview
===============================================================================

Two live "Soundlink" events for Satellaview in 1996 and 1997 focused on F-Zero
and brought with them a fair amount of new content not present in the retail
version of the game. All-in-all, they delivered four new machines, ten new
courses and the "ghost" feature that has become a staple in many racing games
since the game's original inception. Although the original data for a portion
of this new content is well and truly lost, the content itself was rescued and
preserved for the future of gaming.

This hack is a mod for all three versions of F-Zero (Japanese, North American,
PAL) that incorporates all of the Satellaview content directly into the game.



Machines
===============================================================================

Four new machines have been added:

 • Blue Thunder
 • Luna Bomber
 • Green Amazone
 • Fire Scorpion

The machine selection menu, rival selection menu, Records menu and Best 5
results display have been updated to accommodate the additional machines. Any
can be used by the player, and any can be selected as a rival in Practice.

To maintain consistency with competitive play in BS F-Zero 2 Practice, the
machines present in Grand Prix mode (and the order in which they appear at the
startng line) depend on the machine the player selects. If using a machine from
the retail game, the lineup from the retail game is applied. If using a
Satellaview machine, the lineup from BS F-Zero 2 Practice is applied. Bumpers
(the brown and flashing drone machines that appear as obstacles) use the
acceleration data from the corresponding "Blue" machine.



Courses
===============================================================================

Two new Leagues of courses have been added:

BS-1 League, from BS F-Zero Grand Prix 2 week 1:
 • Forest I
 • Big Blue II
 • Sand Storm I
 • Forest II
 • Silence II

BS-2 League, from BS F-Zero Grand Prix 2 week 2:
 • Mute City IV
 • Forest III
 • Sand Storm II
 • Metal Fort I
 • Metal Fort II

Selections for these Leagues have been added to Grand Prix mode.

All 25 courses in the game can now be played in Practice mode, and a new League
selection screen has been added to Practice. Pressing up and down on the
course select screen navigates one course at a time as usual, and pressing
left and right navigates one League at a time.

The Records menu was updated to accommodate the additional courses. Lists for
the BS-1 and BS-2 courses appear to the right of King. While viewing the top
times for a course, navigation with the D-pad works the same as it does on the
Practice course select screen, although it can only navigate to courses with
times recorded for them.



Alternate Courses
===============================================================================

The following courses appeared in BS F-Zero Grand Prix ("GP-1"), and underwent
changes for BS F-Zero Grand Prix 2 ("GP-2"):

  • Big Blue II     Major structural changes
  • Sand Storm I    Cosmetic only
  • Silence II      Minor structural changes
  • Sand Storm II   Cosmetic only

In Practice, press both of the L and R buttons while viewing a compatible
course on the course select screen to access its alternate version.

Individual top time records are saved for each version of Big Blue II and
Silence II due to the structural changes. In Records, press both of the L and R
buttons while viewing the top times for Big Blue II or Silence II to toggle the
alternate version. Under certain conditions, the alternate version of the
course will be presented initially. An alternate version's records will be
inaccessible if there have been no times recorded for it.

When selecting the League for Grand Prix, press both of the L and R buttons to
toggle a list of alternate Leagues. These Leagues match the distributions of
courses as they appeared in BS F-Zero Grand Prix and BS F-Zero 2 Practice:

Ace League, from BS F-Zero 2 Practice:
  • Mute City IV
  • Big Blue II     GP-2 version
  • Sand Storm I    GP-2 version
  • Silence II      GP-2 version
  • Sand Storm II   GP-2 version

GP Knight, from BS F-Zero Grand Prix week 1:
  • Mute City I
  • Big Blue
  • Death Wind I
  • Silence
  • Sand Storm      GP-1 version

GP Queen, from BS F-Zero Grand Prix week 2:
  • Mute City II
  • Port Town I
  • Sand Ocean
  • White Land I
  • Sand Storm II   GP-1 version

GP King, from BS F-Zero Grand Prix week 3:
  • Mute City III
  • Death Wind II
  • Red Canyon I
  • Port Town II
  • Silence II      GP-1 version

GP Ace, from BS F-Zero Grand Prix week 4:
  • Mute City I
  • White Land II
  • Red Canyon II
  • Fire Field
  • Big Blue II     GP-1 version



Ghost
===============================================================================

In Practice mode, a recording of a player's performance can be saved as a
"ghost". The ghost feature is active whenever Practice is played without a
rival, and the player will be prompted to save the ghost after completing the
race. If Ghost is selected on the rival selection menu and a ghost has been
saved on the course being played, the ghost replay will be presented as an
intangible phantom racer on the track alongside the player.

Due to memory constraints, only one ghost can be saved. Saving a ghost will
replace any existing ghost, so care needs to be taken when choosing to save it.

When saving a ghost on Big Blue II or Silence II, the ghost will only apply to
the specific version of the course being played.

If a ghost recording exceeds the maximum amount of memory allocated to it, the
player will not be prompted to save the ghost. This depends on the complexity
of the performance, but in general, the limit won't be reached until
approximately four and a half minutes have elapsed.

The "Now Saving Your Ghost" screen is purely ceremonial and is only present to
simulate the experience from the original Satellaview game. To skip it, use the
Select button to confirm the "Save Ghost?" prompt.



Credits
===============================================================================

Data recovery is based on video recordings by YouTube user kukun kun, who was
apparently present for the original Satellaview broadcasts, recorded them, then
uploaded those recordings to the internet. This project would not have been
possible without their footage, and it's likely the data may have otherwise
been lost for good.

Did You Know Gaming history and technical overview
  • https://youtu.be/sDcrM706gws

Archive footage:
  • https://youtu.be/Rb7V4Qy1j5o   GP-1 Knight
  • https://youtu.be/8Ebw_hsrYD0   GP-1 Queen
  • https://youtu.be/2CVRBWXX5Es   GP-1 King
  • https://youtu.be/D3ET4GNptag   GP-1 Ace
  • https://youtu.be/Z0-Iu-p52ek   GP-2 week 1
  • https://youtu.be/urp8aF71YMY   GP-2 week 2

Modding staff:
  • Catador       Technical QA
  • Guy Perfect   Programming, course recovery
  • Porthor       Course and graphics assistance, community management
  • Power Panda   Graphics recovery, game cover and manual

Quality assurance:
  • ALEJANDRO
  • augitesoul
  • HammerGuy
  • MKDSmaster91
  • Roy's Gaming Garret
  • TheRedMenace

                                                              February 10, 2024

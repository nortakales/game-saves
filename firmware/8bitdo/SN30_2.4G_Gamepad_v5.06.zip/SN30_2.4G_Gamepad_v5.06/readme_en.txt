Update Log：

2021.04.29 8BitDo SN30 2.4g gamepad firmware V5.06
1. Fixed connectivity issue for some controllers.
2. Fixed latency issue for some controllers.


How to upgrade:
1. Unzip the file
2. Press & hold START button to turn off the controller
3. Press & hold L+R buttons, then press START button to enter upgrading mode(Blue and yellow LEDs start to blink)
4. Connect the controller to your PC via USB cable
5. A USB flash drive will be recognised
6. Copy SN30_2.4G_Gamepad_v5.06.dat and paste it to the USB flash drive root directory
7. Disconnect the USB connection, then press & hold START for 3 seconds to turn off the controller.
8. Upgrade completed.
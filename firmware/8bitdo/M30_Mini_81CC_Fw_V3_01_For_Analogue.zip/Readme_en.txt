Update firmware[For Windows]:
1. Extract the zip file.
2. Hold down the start button for 3 seconds to turn off the controller.(Skip this step if the controller is already powered off)
3. Hold down L & R at the same time, then press start button to enter its upgrade mode, blue and yellow LEDs start to blink.
4. Connect the controller to PC via USB cable.
5. For old controller: It will be recognized as an USB flash drive.
   For new controller: It Will be recognized as an hid device, not flash drive.
6. Open the exe update tools.
7. Click "USB update" and choose the .dat file.
8. Wait till the completion.
9. Unplug the USB cable.
10. Hold down start button for 3 seconds until all LEDs turn off, upgrade complete.

Tips:
	For old, the controller will be recognized as an USB flash drive, you can use the way to update:
	Copy the .dat file and paste it to the USB flash drive(The controller), then wait till the completion.

Update firmware(For MacOSX):
1. Extract the zip file.
2. Hold down the start button for 3 seconds to turn off the controller.(Skip this step if the controller is already powered off)
3. Hold down L & R at the same time, then press start button to enter its upgrade mode, blue and yellow LEDs start to blink.
4. Connect the controller to PC via USB cable.
5. The controller will be recognized as an USB flash drive.
6. Search for the keyword terminal, double click terminal to open it.
7. In terminal, input the text 'cp' and space.
8. Drag the .dat file to terminal.
9. Drag the USB flash drive(The controller) to terminal.
10. Press the Enter key of keyboard, wait 2 seconds.
11. Unplug the USB cable.
12. Hold down start button for 3 seconds until all LEDs turn off, upgrade complete.

Tips:
	For old controller: It will be recognized as an USB flash drive, you can use the way to update:
		Copy the .dat file and paste it to the USB flash drive(The controller), then wait till the completion.

	For new controller: not support MacOSX to update firmware.


Pair with the Analogue Dock:
1. Press start button to turn on the controller.
2. Hold down the select button for 3 seconds to enter its pairing mode, blue LED flashes rapidly.
3. Press the Dock button to enter its pairing mode.
4. The blue LED of the controller stays solid when the connection is successful.


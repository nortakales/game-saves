Use the 'file menu' to set the background.
A Background image should be in JPG format, with a resolution of 320x240 and a maximum size of 150KB.
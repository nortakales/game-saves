------------------------------------------------------------------------------------- system folders description

OS64.v64
 System menu

/save_db.txt
 Configuration file with game settings
 It can override default game settings

/syscore
 Various files used by the system
 System does not create any new files in this folder

/sysdata
 All files created by the system stored in this folder
 System setting will be reset to default if all files in this folder will be removed

/gamedata
 All game data stored here (saves, cheats, etc.)

/emu
 Store emulators in this folder.
 The emulator name should match to the target ROM extension
 example: "nes.v64" for .nes files, "gbc.v64" for .gbc and so on

/bgr
 Just a background files examples. You can remove it

------------------------------------------------------------------------------------- ips/aps patcher description

The built-in auto patcher engine allows using ips/aps patches without using patching
software. The ROM stays unchanged on the SD card but patched in cart RAM. Patch file should
be located in the same folder with ROM file and ips file name should match to the ROM name